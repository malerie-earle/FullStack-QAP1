// Title: Full Stack JavaScript - QAP 1
// Program Description: QAP 1, Sem 3, Full Stack JavaScript
// Written By Malerie Earle
// Date Submitted - January 26, 2024

// import uuid module
const { v4: uuidv4 } = require('uuid');
console.log(uuidv4()); // create a globally unique id

// Solution: 07605bcc-c55b-44bc-aa51-f9a7787cdfab